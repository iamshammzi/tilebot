package com.example.tilebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import androidx.core.content.IntentCompat

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val detector = TileDetector()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, buildNotification())
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        thread = HandlerThread("TileCaptureThread").also { it.start() }
        val handler = Handler(thread!!.looper)

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val proj = mgr.getMediaProjection(code, data)
        projection = proj

        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        Config.screenW = bounds.width()
        Config.screenH = bounds.height()

        val captureW = bounds.width() / Config.SCALE
        val captureH = bounds.height() / Config.SCALE

        val imgReader = ImageReader.newInstance(captureW, captureH, PixelFormat.RGBA_8888, 2)
        reader = imgReader

        display = proj.createVirtualDisplay(
            "TileBotVirtualDisplay",
            captureW,
            captureH,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imgReader.surface,
            null,
            handler
        )

        imgReader.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                detector.process(image)
            } finally {
                image.close()
            }
        }, handler)

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        TapService.instance?.releaseAll()
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val channelId = "tilebot_channel"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "TileBot Service", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("TileBot Active")
            .setContentText("Monitoring tiles and automating touches...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }
}
