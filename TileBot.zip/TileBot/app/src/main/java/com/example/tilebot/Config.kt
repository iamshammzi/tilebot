package com.example.tilebot

object Config {
    const val LANES = 4
    const val SCALE = 2  // Downscale factor for high frame rate and sharp detection

    // Screen lane centers (fractions of width: 0.125, 0.375, 0.625, 0.875)
    val laneFractions = floatArrayOf(0.125f, 0.375f, 0.625f, 0.875f)

    // Dual-line trigger system
    @Volatile var triggerFrac = 0.70f    // Primary strike line (70% screen height)
    @Volatile var lookaheadFrac = 0.52f  // Lookahead line to distinguish tap vs long slider

    // In Piano Tiles: background lavender has R > 125; black tiles R < 20; blue sliders R < 95
    @Volatile var redThreshold = 95

    // Timing constants
    const val TAP_DURATION_MS = 12L
    const val HOLD_STEP_MS = 40L
    const val MIN_RETRIGGER_MS = 35L

    @Volatile var screenW = 0
    @Volatile var screenH = 0
}
