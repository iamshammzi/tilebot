package com.example.tilebot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", r.resultCode).putExtra("data", data)
            )
            Toast.makeText(this, "Armed. Switch to the game: starts in 3s", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { launchCapture() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Config.triggerFrac = prefs.getInt("trig", 70) / 100f
        Config.redThreshold = prefs.getInt("red", 95)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply {
            text = "1. Enable the TileBot accessibility service (if blocked: App info > menu > Allow restricted settings).\n" +
                "2. Tap Start, choose \"Entire screen\", then open the game. Bot begins after 3 s.\n" +
                "Sliders below adjust timing and tile sensitivity."
        })
        root.addView(Button(this).apply {
            text = "1. Open accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply { text = "2. Start"; setOnClickListener { onStart() } })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })

        slider(root, "Trigger line (% of height)", 30, 85, (Config.triggerFrac * 100).toInt()) {
            Config.triggerFrac = it / 100f; prefs.edit().putInt("trig", it).apply()
        }
        slider(root, "Red color threshold", 30, 160, Config.redThreshold) {
            Config.redThreshold = it; prefs.edit().putInt("red", it).apply()
        }
        setContentView(root)
    }

    private fun onStart() {
        if (TapService.instance == null) {
            Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else launchCapture()
    }

    private fun launchCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        projLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun slider(root: LinearLayout, label: String, min: Int, max: Int, init: Int, on: (Int) -> Unit) {
        val tv = TextView(this).apply { text = "$label: $init"; setPadding(0, 32, 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = init - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    tv.text = "$label: ${p + min}"; on(p + min)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(tv); root.addView(sb)
    }
}
