package com.example.tilebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

class TapService : AccessibilityService() {

    companion object {
        @Volatile var instance: TapService? = null
    }

    private class Action(val lane: Int, val hold: Boolean)
    private class HoldState(var stroke: StrokeDescription, val x: Float, val y: Float)

    private val mainHandler = Handler(Looper.getMainLooper())
    private val actionQueue = ConcurrentLinkedQueue<Action>()
    private val activeHolds = HashMap<Int, HoldState>()
    private val keepHoldingMask = AtomicInteger(0)
    private var inFlight = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun tap(lane: Int) {
        actionQueue.add(Action(lane, false))
        mainHandler.post { processQueue() }
    }

    fun press(lane: Int) {
        keepHoldingMask.updateAndGet { it or (1 shl lane) }
        actionQueue.add(Action(lane, true))
        mainHandler.post { processQueue() }
    }

    fun release(lane: Int) {
        keepHoldingMask.updateAndGet { it and (1 shl lane).inv() }
        mainHandler.post { processQueue() }
    }

    fun releaseAll() {
        keepHoldingMask.set(0)
        mainHandler.post { processQueue() }
    }

    private fun processQueue() {
        if (inFlight) return

        val strokes = ArrayList<StrokeDescription>()
        val lanesHandled = HashSet<Int>()

        // 1. Maintain active long-press holds
        val iterator = activeHolds.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val lane = entry.key
            val state = entry.value
            val continueHold = (keepHoldingMask.get() and (1 shl lane)) != 0

            val path = Path().apply { moveTo(state.x, state.y) }
            state.stroke = state.stroke.continueStroke(
                path,
                0,
                if (continueHold) Config.HOLD_STEP_MS else 10L,
                continueHold
            )
            strokes.add(state.stroke)
            lanesHandled.add(lane)

            if (!continueHold) {
                iterator.remove()
            }
        }

        // 2. Consume queued taps or new holds
        while (true) {
            val action = actionQueue.poll() ?: break
            if (action.lane in lanesHandled) continue

            val x = Config.screenW * Config.laneFractions[action.lane]
            val y = Config.screenH * Config.triggerFrac
            val path = Path().apply { moveTo(x, y) }

            if (action.hold) {
                val stroke = StrokeDescription(path, 0, Config.HOLD_STEP_MS, true)
                activeHolds[action.lane] = HoldState(stroke, x, y)
                strokes.add(stroke)
            } else {
                strokes.add(StrokeDescription(path, 0, Config.TAP_DURATION_MS, false))
            }
            lanesHandled.add(action.lane)
        }

        if (strokes.isEmpty()) return

        val gesture = GestureDescription.Builder().apply {
            strokes.forEach { addStroke(it) }
        }.build()

        inFlight = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                inFlight = false
                processQueue()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                inFlight = false
                activeHolds.clear()
                processQueue()
            }
        }, null)
    }
}
