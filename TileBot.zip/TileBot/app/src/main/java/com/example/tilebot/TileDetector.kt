package com.example.tilebot

import android.media.Image
import android.os.SystemClock

class TileDetector {
    private enum class LaneState { IDLE, HOLDING, COOLING }

    private val states = Array(Config.LANES) { LaneState.IDLE }
    private val lastActionTime = LongArray(Config.LANES)
    private val armedAt = SystemClock.uptimeMillis() + 3000L

    fun process(img: Image) {
        val now = SystemClock.uptimeMillis()
        if (now < armedAt) return
        val svc = TapService.instance ?: return

        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val w = img.width
        val h = img.height

        val trigY = (h * Config.triggerFrac).toInt().coerceIn(0, h - 1)
        val lookY = (h * Config.lookaheadFrac).toInt().coerceIn(0, h - 1)

        fun isTile(cx: Int, cy: Int): Boolean {
            val offset = cy * rs + cx * ps
            if (offset + 2 >= buf.limit()) return false
            val r = buf.get(offset).toInt() and 0xFF
            return r < Config.redThreshold
        }

        for (lane in 0 until Config.LANES) {
            val cx = (w * Config.laneFractions[lane]).toInt()
            val tileAtTrigger = isTile(cx, trigY)

            when (states[lane]) {
                LaneState.IDLE -> {
                    if (tileAtTrigger && (now - lastActionTime[lane] >= Config.MIN_RETRIGGER_MS)) {
                        val tileAtLookahead = isTile(cx, lookY)
                        if (tileAtLookahead) {
                            // Tile stretches across both scanlines -> Long slider
                            states[lane] = LaneState.HOLDING
                            lastActionTime[lane] = now
                            svc.press(lane)
                        } else {
                            // Tile is only at the trigger line -> Quick single tap
                            states[lane] = LaneState.COOLING
                            lastActionTime[lane] = now
                            svc.tap(lane)
                        }
                    }
                }
                LaneState.HOLDING -> {
                    // Release when the tail of the long slider clears the trigger line
                    if (!tileAtTrigger) {
                        svc.release(lane)
                        states[lane] = LaneState.COOLING
                        lastActionTime[lane] = now
                    }
                }
                LaneState.COOLING -> {
                    // Ready for next tile once previous tile clears or short cooldown elapses
                    if (!tileAtTrigger || (now - lastActionTime[lane] >= 60L)) {
                        states[lane] = LaneState.IDLE
                    }
                }
            }
        }
    }
}
